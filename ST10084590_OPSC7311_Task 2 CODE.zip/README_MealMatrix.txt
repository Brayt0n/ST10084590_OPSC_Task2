==============================================================================================================
	                                             Meal Matrix		
==============================================================================================================

Thank you for installing the Meal Matrix health and fitness mobile app. This Readme file contains everything you need to get going.

== Minimum Sepcifications Needed ==

 For running on your device:

 * Android 10 or higher
 * 6gb RAM
 * 50MB storage available
 * Octa core or any similar processor
 
For running on windows:

 * Windows 10 or higher
 * Ryzen 5 or any higher equivalent processor
 * Minimum 12gb
 * Minimum 1gb storage

== Installation  ==

 1) If you do not have Android Studio installed, please use the following link to download the 
    software: https://developer.android.com/studio?gclid=CjwKCAjw1YCkBhAOEiwA5aN4AQ9a_mVoW16gFA1H14bx4sWRDmNv4mIRjywCUwuGUZ9XMLuKXbs52hoC41MQAvD_BwE&gclsrc=aw.ds
 2) If you do have ANdroid Studio installed, extract the MealMatrix folder from the zip folder.
 3) Paste the MealMatrix folder in your local AndroidStudioProjects folder
 4) Open Android Studio and run the folder with your emulator or paired device.

== How to Use ==
  
 1) After installing the project and running it on your emulator or paired device, you will be prompted to login. 
 2) Login with your credentials, however if you are a new user do the following
 	2.1) If you do not have an account, press the red Register tag to proceed to the register screen.
 	2.2) Enter your email and desired password, then confirm your password. You will then be directed to the login screen.
 	2.3) Login with your credentials
 3) You will then be directed to the main screen, from here you can access all the app's features via the hamburger.
 4) To use the Stopwatch:
 	4.1) Acesss the stopwatch from the hamburger.
        4.2) Press the start button to start the timer. You can optionally add laps, these laps will tabulate a graph.
        4.3) To stop the timer simply press stop.
 5) To use the Food Logger Feature:
        5.1) Access the Food Logger from the menu
        5.2) Enter the name of your meal.
        5.3) Select the mealtime.
        5.4) Take an image of your meal via the camera button.
        5.5) Press save.
 6.1) To use the Workout Tracker feature
        6.1.1) Access the workout feature from the menu
        6.1.2) Enter the name of your workout.
        6.1.3) Select the start date of your workout.
        6.1.4) Select the end date of your workout.
        6.1.5) Select the start time of your workout.
        6.1.6) Select the end time of your workout.
        6.1.7) Select the category of your workout.
        6.1.8) Enter the description of your workout.
        6.1.9) Press the track button.
        6.1.10) Your data will now be populated to a list.
 6.2) To use the goal tracker feature:
       6.2.1) Within the Workout Tracker feature, click the goal button next to the end time button.
       6.2.2) Enter your minimum goal.
       6.2.3) Enter your maximum goal.
       6.2.4) Enter the hours you actually worked out for.
       6.2.5) Press the track button.
       6.2.6) Your goals will now be saved to a list.
 7) To logout simply access the option from the menu and select the logout option.

== Default Login == 

   Email: test@gmail.com
   Password: Pass123@

== Troubleshooting ==

   If the app crashes on launch, please do the following:
   1) Please rebuild the program then run it.
   2) Sometimes, .NoActionBar gets deleted, therefore paste it at the end of line 14 of the android manifest.
   
== FAQ's ==

 Q: Can I download the app of the Play Store?
 A: No, at the momemnt the Meal Matrix app is not published on the Google Play Store.
 
 Q: How do I earn achievements?
 A: You have to workout more than your maximum goal that you set.
 
 Q: What is the purpose of the app?
 A: Meal Matrix was created for the purpose of tracking people's fitness goals, and allows them to clearly track their progress.

 Q: How do I take a picture of my meals?
 A: You simply have to click the camera button in the Food Logger feature and then click the save button to save your image.

== Plugins used ==

 1) GitHub Chart resources: com.github.Philjay:MPAndroidChart:v3.0.3
 2) GitHub GIF glide: com.github.bumptech.glide:glide:4.11.0

== GitHub Repository Link ==

 https://github.com/Brayt0n/ST10084590_OPSC_Task2.git

== Author Information ==

 Author Name: Brayton 
 Author Surname: Chetty
 Business Address: 1 Link Road St James Avenue, Westvile, Durban, 3630

 If you encounter any bugs while running the app please contact me on Outlook via my business email: ST10084590@vcconnect.edu.za

== Reference List ==

 1. Play GIF in android app 2022 | android studio | kotlin. 2022. YouTube video, added by Picker Soft. [Online]. Available at:
    https://www.youtube.com/watch?v=cGIaRC7j1iw [Accessed 1 June 2023].
 2. How to create a Custom Toast Message in Android Studio (Kotlin 2020). 2020. YouTube video, added by Identity. [Online]. Available at:
    https://www.youtube.com/watch?v=DAWmKXOqSyo&t=10s [Accessed 7 June 2023].
 3. Color Psychology & How it Affects Your Fitness Center. 2023. [Image]. Available at: 
    https://images.squarespace-cdn.com/content/v1/5ada11772714e5eb213ab1df/1598971615118-52I7A8XS2KXHXGXII3YI/Color-Psychology-01-compressed.jpg
    [Accessed 3 June 2023].